package vista;

public class VistaException extends Exception {

  public VistaException(String mensaje) {
    super(mensaje);
  }

}
