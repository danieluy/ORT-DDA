package modelo;

public class Administrador extends Usuario {

  public Administrador(String nombre, String nombreCompleto, String password) {
    super(nombre, nombreCompleto, password);
  }

}
