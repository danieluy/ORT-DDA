package modelo;

public class UsuarioException extends Exception {

  public UsuarioException(String mensaje) {
    super(mensaje);
  }

}
