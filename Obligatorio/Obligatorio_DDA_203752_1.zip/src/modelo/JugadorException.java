package modelo;

public class JugadorException extends Exception {

  public JugadorException(String mensaje) {
    super(mensaje);
  }

}
