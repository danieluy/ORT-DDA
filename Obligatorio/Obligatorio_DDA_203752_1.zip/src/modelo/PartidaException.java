package modelo;

public class PartidaException extends Exception {

  public PartidaException(String mensaje) {
    super(mensaje);
  }

}
