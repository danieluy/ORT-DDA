package modelo;

public class CasilleroException extends Exception {

  public CasilleroException(String mensaje) {
    super(mensaje);
  }

}
