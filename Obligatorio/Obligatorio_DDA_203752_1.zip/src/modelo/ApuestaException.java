package modelo;

public class ApuestaException extends Exception {

  public ApuestaException(String mensaje) {
    super(mensaje);
  }

}
