package modelo;

import java.awt.Color;

public class Mina {

  private Color color = Color.RED;

  public Color getColor() {
    return color;
  }

}
