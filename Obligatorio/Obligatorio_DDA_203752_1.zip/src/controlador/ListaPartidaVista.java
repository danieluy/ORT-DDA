package controlador;

import java.util.ArrayList;

public interface ListaPartidaVista {

  public void mostrarPartidas(ArrayList<String> partidas);

}
