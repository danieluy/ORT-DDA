package controlador;

public interface InicioVista {

  public void loginJugador();

  public void loginAdministrador();

  public void mostrarError(String mensaje);

}
